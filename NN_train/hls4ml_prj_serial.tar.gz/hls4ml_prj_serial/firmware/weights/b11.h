//Numpy array shape [5]
//Min -1.000000000000
//Max 0.968750000000
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[5];
#else
bias11_t b11[5] = {-0.03125, -1.00000, 0.96875, -0.28125, -1.00000};
#endif

#endif
