#include "dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_115_fu_20319_p4() {
    trunc_ln708_115_fu_20319_p4 = mul_ln1118_97_reg_23776.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_116_fu_20328_p4() {
    trunc_ln708_116_fu_20328_p4 = mul_ln1118_98_reg_23781.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_117_fu_20941_p4() {
    trunc_ln708_117_fu_20941_p4 = mul_ln1118_99_reg_24081.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_118_fu_20950_p4() {
    trunc_ln708_118_fu_20950_p4 = mul_ln1118_100_reg_24086.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_119_fu_20361_p4() {
    trunc_ln708_119_fu_20361_p4 = mul_ln1118_101_reg_23786.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_120_fu_20370_p4() {
    trunc_ln708_120_fu_20370_p4 = mul_ln1118_102_reg_23791.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_121_fu_20379_p4() {
    trunc_ln708_121_fu_20379_p4 = mul_ln1118_103_reg_23796.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_122_fu_20959_p4() {
    trunc_ln708_122_fu_20959_p4 = mul_ln1118_104_reg_24091.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_123_fu_20968_p4() {
    trunc_ln708_123_fu_20968_p4 = mul_ln1118_105_reg_24096.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_124_fu_20388_p4() {
    trunc_ln708_124_fu_20388_p4 = mul_ln1118_106_reg_23801.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_125_fu_20397_p4() {
    trunc_ln708_125_fu_20397_p4 = mul_ln1118_107_reg_23806.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_29_fu_19659_p4() {
    trunc_ln708_29_fu_19659_p4 = mul_ln1118_11_reg_23516.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_30_fu_19668_p4() {
    trunc_ln708_30_fu_19668_p4 = mul_ln1118_12_reg_23521.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_31_fu_19677_p4() {
    trunc_ln708_31_fu_19677_p4 = mul_ln1118_13_reg_23526.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_32_fu_20438_p4() {
    trunc_ln708_32_fu_20438_p4 = mul_ln1118_14_reg_23821.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_33_fu_20447_p4() {
    trunc_ln708_33_fu_20447_p4 = mul_ln1118_15_reg_23826.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_34_fu_19686_p4() {
    trunc_ln708_34_fu_19686_p4 = mul_ln1118_16_reg_23531.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_35_fu_19695_p4() {
    trunc_ln708_35_fu_19695_p4 = mul_ln1118_17_reg_23536.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_36_fu_19704_p4() {
    trunc_ln708_36_fu_19704_p4 = mul_ln1118_18_reg_23541.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_37_fu_20477_p4() {
    trunc_ln708_37_fu_20477_p4 = mul_ln1118_19_reg_23841.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_38_fu_20486_p4() {
    trunc_ln708_38_fu_20486_p4 = mul_ln1118_20_reg_23846.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_39_fu_19737_p4() {
    trunc_ln708_39_fu_19737_p4 = mul_ln1118_21_reg_23546.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_40_fu_19746_p4() {
    trunc_ln708_40_fu_19746_p4 = mul_ln1118_22_reg_23551.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_41_fu_19755_p4() {
    trunc_ln708_41_fu_19755_p4 = mul_ln1118_23_reg_23556.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_42_fu_20495_p4() {
    trunc_ln708_42_fu_20495_p4 = mul_ln1118_24_reg_23851.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_43_fu_20504_p4() {
    trunc_ln708_43_fu_20504_p4 = mul_ln1118_25_reg_23856.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_44_fu_19764_p4() {
    trunc_ln708_44_fu_19764_p4 = mul_ln1118_26_reg_23561.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_45_fu_19773_p4() {
    trunc_ln708_45_fu_19773_p4 = mul_ln1118_27_reg_23566.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_46_fu_19782_p4() {
    trunc_ln708_46_fu_19782_p4 = mul_ln1118_28_reg_23571.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_47_fu_20535_p4() {
    trunc_ln708_47_fu_20535_p4 = mul_ln1118_29_reg_23871.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_48_fu_20544_p4() {
    trunc_ln708_48_fu_20544_p4 = mul_ln1118_30_reg_23876.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_49_fu_19815_p4() {
    trunc_ln708_49_fu_19815_p4 = mul_ln1118_31_reg_23576.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_50_fu_19824_p4() {
    trunc_ln708_50_fu_19824_p4 = mul_ln1118_32_reg_23581.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_51_fu_19833_p4() {
    trunc_ln708_51_fu_19833_p4 = mul_ln1118_33_reg_23586.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_52_fu_20553_p4() {
    trunc_ln708_52_fu_20553_p4 = mul_ln1118_34_reg_23881.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_53_fu_20562_p4() {
    trunc_ln708_53_fu_20562_p4 = mul_ln1118_35_reg_23886.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_54_fu_19842_p4() {
    trunc_ln708_54_fu_19842_p4 = mul_ln1118_36_reg_23591.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_55_fu_19851_p4() {
    trunc_ln708_55_fu_19851_p4 = mul_ln1118_37_reg_23596.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_56_fu_19860_p4() {
    trunc_ln708_56_fu_19860_p4 = mul_ln1118_38_reg_23601.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_57_fu_20593_p4() {
    trunc_ln708_57_fu_20593_p4 = mul_ln1118_39_reg_23901.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_58_fu_20602_p4() {
    trunc_ln708_58_fu_20602_p4 = mul_ln1118_40_reg_23906.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_59_fu_19893_p4() {
    trunc_ln708_59_fu_19893_p4 = mul_ln1118_41_reg_23606.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_60_fu_19902_p4() {
    trunc_ln708_60_fu_19902_p4 = mul_ln1118_42_reg_23611.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_61_fu_19911_p4() {
    trunc_ln708_61_fu_19911_p4 = mul_ln1118_43_reg_23616.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_62_fu_20611_p4() {
    trunc_ln708_62_fu_20611_p4 = mul_ln1118_44_reg_23911.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_63_fu_20620_p4() {
    trunc_ln708_63_fu_20620_p4 = mul_ln1118_45_reg_23916.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_64_fu_19920_p4() {
    trunc_ln708_64_fu_19920_p4 = mul_ln1118_46_reg_23621.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_65_fu_19929_p4() {
    trunc_ln708_65_fu_19929_p4 = mul_ln1118_47_reg_23626.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_66_fu_19938_p4() {
    trunc_ln708_66_fu_19938_p4 = mul_ln1118_48_reg_23631.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_67_fu_20651_p4() {
    trunc_ln708_67_fu_20651_p4 = mul_ln1118_49_reg_23931.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_68_fu_20660_p4() {
    trunc_ln708_68_fu_20660_p4 = mul_ln1118_50_reg_23936.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_69_fu_19971_p4() {
    trunc_ln708_69_fu_19971_p4 = mul_ln1118_51_reg_23636.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_70_fu_19980_p4() {
    trunc_ln708_70_fu_19980_p4 = mul_ln1118_52_reg_23641.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_71_fu_19989_p4() {
    trunc_ln708_71_fu_19989_p4 = mul_ln1118_53_reg_23646.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_72_fu_20669_p4() {
    trunc_ln708_72_fu_20669_p4 = mul_ln1118_54_reg_23941.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_73_fu_20678_p4() {
    trunc_ln708_73_fu_20678_p4 = mul_ln1118_55_reg_23946.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_74_fu_19998_p4() {
    trunc_ln708_74_fu_19998_p4 = mul_ln1118_56_reg_23651.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_75_fu_20007_p4() {
    trunc_ln708_75_fu_20007_p4 = mul_ln1118_57_reg_23656.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_76_fu_20016_p4() {
    trunc_ln708_76_fu_20016_p4 = mul_ln1118_58_reg_23661.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_77_fu_20709_p4() {
    trunc_ln708_77_fu_20709_p4 = mul_ln1118_59_reg_23961.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_78_fu_20718_p4() {
    trunc_ln708_78_fu_20718_p4 = mul_ln1118_60_reg_23966.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_79_fu_20049_p4() {
    trunc_ln708_79_fu_20049_p4 = mul_ln1118_61_reg_23666.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_80_fu_20058_p4() {
    trunc_ln708_80_fu_20058_p4 = mul_ln1118_62_reg_23671.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_81_fu_20067_p4() {
    trunc_ln708_81_fu_20067_p4 = mul_ln1118_63_reg_23676.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_82_fu_20727_p4() {
    trunc_ln708_82_fu_20727_p4 = mul_ln1118_64_reg_23971.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_83_fu_20736_p4() {
    trunc_ln708_83_fu_20736_p4 = mul_ln1118_65_reg_23976.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_84_fu_20076_p4() {
    trunc_ln708_84_fu_20076_p4 = mul_ln1118_66_reg_23681.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_85_fu_20085_p4() {
    trunc_ln708_85_fu_20085_p4 = mul_ln1118_67_reg_23686.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_86_fu_20094_p4() {
    trunc_ln708_86_fu_20094_p4 = mul_ln1118_68_reg_23691.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_87_fu_20767_p4() {
    trunc_ln708_87_fu_20767_p4 = mul_ln1118_69_reg_23991.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_88_fu_20776_p4() {
    trunc_ln708_88_fu_20776_p4 = mul_ln1118_70_reg_23996.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_89_fu_20127_p4() {
    trunc_ln708_89_fu_20127_p4 = mul_ln1118_71_reg_23696.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_90_fu_20136_p4() {
    trunc_ln708_90_fu_20136_p4 = mul_ln1118_72_reg_23701.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_91_fu_20145_p4() {
    trunc_ln708_91_fu_20145_p4 = mul_ln1118_73_reg_23706.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_92_fu_20785_p4() {
    trunc_ln708_92_fu_20785_p4 = mul_ln1118_74_reg_24001.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_93_fu_20794_p4() {
    trunc_ln708_93_fu_20794_p4 = mul_ln1118_75_reg_24006.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_94_fu_20154_p4() {
    trunc_ln708_94_fu_20154_p4 = mul_ln1118_76_reg_23711.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_95_fu_20163_p4() {
    trunc_ln708_95_fu_20163_p4 = mul_ln1118_77_reg_23716.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_96_fu_20172_p4() {
    trunc_ln708_96_fu_20172_p4 = mul_ln1118_78_reg_23721.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_97_fu_20825_p4() {
    trunc_ln708_97_fu_20825_p4 = mul_ln1118_79_reg_24021.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_98_fu_20834_p4() {
    trunc_ln708_98_fu_20834_p4 = mul_ln1118_80_reg_24026.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_99_fu_20205_p4() {
    trunc_ln708_99_fu_20205_p4 = mul_ln1118_81_reg_23726.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln708_s_fu_20429_p4() {
    trunc_ln708_s_fu_20429_p4 = mul_ln1118_10_reg_23816.read().range(20, 5);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_trunc_ln76_fu_17611_p1() {
    trunc_ln76_fu_17611_p1 = w10_V_q0.read().range(6-1, 0);
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_w10_V_address0() {
    w10_V_address0 =  (sc_lv<6>) (zext_ln76_fu_14726_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_w10_V_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        w10_V_ce0 = ap_const_logic_1;
    } else {
        w10_V_ce0 = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_w_index_fu_14720_p2() {
    w_index_fu_14720_p2 = (!ap_const_lv6_1.is_01() || !ap_phi_mux_w_index25_phi_fu_9369_p6.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_1) + sc_biguint<6>(ap_phi_mux_w_index25_phi_fu_9369_p6.read()));
}

void dense_wrapper_ap_fixed_ap_fixed_16_6_5_3_0_config10_s::thread_zext_ln76_fu_14726_p1() {
    zext_ln76_fu_14726_p1 = esl_zext<64,6>(ap_phi_mux_w_index25_phi_fu_9369_p6.read());
}

}

