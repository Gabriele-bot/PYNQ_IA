//Numpy array shape [10]
//Min -0.093750000000
//Max 0.218750000000
//Number of zeros 3

#ifndef B10_H_
#define B10_H_

#ifndef __SYNTHESIS__
bias10_t b10[10];
#else
bias10_t b10[10] = {-0.03125, 0.21875, 0.00000, 0.00000, -0.06250, 0.00000, 0.03125, -0.03125, -0.09375, 0.03125};
#endif

#endif
