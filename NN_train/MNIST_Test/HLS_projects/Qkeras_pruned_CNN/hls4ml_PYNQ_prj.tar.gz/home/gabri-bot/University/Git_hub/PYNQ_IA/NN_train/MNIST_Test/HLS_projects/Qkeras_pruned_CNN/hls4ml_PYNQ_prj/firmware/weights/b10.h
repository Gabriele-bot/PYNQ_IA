//Numpy array shape [10]
//Min -0.281250000000
//Max 0.343750000000
//Number of zeros 3

#ifndef B10_H_
#define B10_H_

#ifndef __SYNTHESIS__
bias10_t b10[10];
#else
bias10_t b10[10] = {0.34375, 0.34375, 0.00000, -0.28125, 0.00000, -0.28125, 0.12500, -0.09375, 0.00000, 0.18750};
#endif

#endif
