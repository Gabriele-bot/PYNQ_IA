//Numpy array shape [5]
//Min -0.112370252609
//Max 0.074049234390
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
output_bias_t b11[5];
#else
output_bias_t b11[5] = {0.0194965098, 0.0371186994, 0.0740492344, -0.0542030558, -0.1123702526};
#endif

#endif
