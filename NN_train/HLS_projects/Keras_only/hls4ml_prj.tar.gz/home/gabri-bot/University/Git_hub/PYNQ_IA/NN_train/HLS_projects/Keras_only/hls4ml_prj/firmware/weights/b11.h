//Numpy array shape [5]
//Min -0.113459296525
//Max 0.074209421873
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
output_bias_t b11[5];
#else
output_bias_t b11[5] = {0.0207988918, 0.0379616655, 0.0742094219, -0.0559439212, -0.1134592965};
#endif

#endif
